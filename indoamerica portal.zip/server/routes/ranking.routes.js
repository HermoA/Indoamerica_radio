import { Router } from "express";
import {
  getRankings,
  getRanking,
  postRanking,
  putRanking,
  deleteRanking,
  nombreRanking,
} from "../controllers/ranking.controllers.js";

const router = Router();

router.get("/ranking", getRankings);
router.get("/rankingmax", getRanking);
router.get("/rankin/nombre", nombreRanking);
router.post("/ranking", postRanking);
router.put("/ranking/:id", putRanking);
router.delete("/ranking/:id", deleteRanking);

export default router;
