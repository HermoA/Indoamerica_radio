import { Router } from "express";
import multer from "multer";
import {
  getProgramas,
  getPrograma,
  postPrograma,
  putProgama,
  deleteProgama,
} from "../controllers/programa.controllers.js";
import { verificando, isAdmin } from "../controllers/login.controllers.js";

const router = Router();
const upload = multer({ dest: "uploadftp/" });

router.get("/programas", getProgramas);
router.get("/programa/:id", getPrograma);
router.post("/programa", upload.single("image"), postPrograma);
router.put("/programa/:id", putProgama);
router.delete("/programa/:id", deleteProgama);

export default router;
