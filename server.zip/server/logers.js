import dotenv from "dotenv";
import fs from "fs";
import { createPool } from "mysql2/promise";

dotenv.config();

// Redirigir logs a archivo
const logStream = fs.createWriteStream("app.log", { flags: "a" });
console.log = function (msg) {
  logStream.write("[LOG] " + msg + "\n");
};
console.error = function (msg) {
  logStream.write("[ERROR] " + msg + "\n");
};

// Configuración de la base de datos
const config = {
  host: process.env.HOST,
  port: process.env.PORTDB,
  user: process.env.USER,
  password: process.env.PASSWORD,
  database: process.env.DATABASE,
};

const pool = createPool(config);

// Verificar conexión
(async () => {
  try {
    const conn = await pool.getConnection();
    console.log("✅ Conectado a MySQL correctamente");
    conn.release();
  } catch (error) {
    console.error("❌ Error al conectar a MySQL:", error.message);
  }
})();

export { pool };
