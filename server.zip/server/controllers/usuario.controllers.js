import { pool } from "../db.js";
import bcrypt from "bcryptjs";

//-----------------Recivir datos --------------------//
export const getUsers = async (req, res) => {
  try {
    const [result] = await pool.query("SELECT * FROM usuarios");
    res.json(result);
  } catch (error) {
    res.status(500).json({ message: "Error al obtener los usuarios" });
  }
};

//-----------------Recivir un dato --------------------//
export const getUser = async (req, res) => {
  try {
    const [result] = await pool.query(
      "SELECT created_at, email_usuario, id_usuario, nombre_usuario FROM usuarios WHERE id_usuario = ?",
      [req.params.id]
    );

    if (result.length === 0) {
      return res.status(404).json({ message: "Usuario no encontrado" });
    }

    res.json(result[0]);
  } catch (error) {
    res.status(500).json({ message: "Error al obtener el usuario" });
  }
};

//-----------------Crear datos --------------------//
export const postUser = async (req, res) => {
  try {
    const { nombre, email, password, rol } = req.body;

    // Verificar si el usuario ya existe
    const [users] = await pool.query(
      "SELECT * FROM usuarios WHERE nombre_usuario = ?",
      [nombre]
    );
    if (users.length > 0) {
      return res.status(400).json({ message: "El usuario ya existe" });
    }

    // Encriptar contraseña antes de guardarla
    const hashedPassword = await bcrypt.hash(password, 10);

    const [result] = await pool.query(
      "INSERT INTO usuarios (nombre_usuario, email_usuario, password, rol) VALUES (?, ?, ?, ?)",
      [nombre, email, hashedPassword, rol]
    );

    res.json({
      message: "Usuario creado correctamente",
      id: result.insertId,
      nombre,
      email,
      rol,
    });
  } catch (error) {
    res.status(500).json({ message: "Error al crear el usuario" });
  }
};

//-----------------Actualizar datos --------------------//
export const updateUser = async (req, res) => {
  try {
    const { id } = req.params; // Se espera que el ID del usuario venga como parámetro en la URL
    const { nombre_usuario, email_usuario, password } = req.body;

    

    // Verificar si el usuario existe
     const [users] = await pool.query("SELECT * FROM usuarios WHERE id_usuario = ?", [id]);
     if (users.length === 0) {
       return res.status(404).json({ message: "Usuario no encontrado" });
     }    

    // Encriptar la nueva contraseña solo si se proporciona
    let hashedPassword = users[0].password;
     if (password) {
       hashedPassword = await bcrypt.hash(password, 10);
     }

     // Actualizar los datos
     await pool.query(
       "UPDATE usuarios SET nombre_usuario = ?, email_usuario = ?, password = ? WHERE id_usuario = ?",
       [nombre_usuario, email_usuario, hashedPassword, id]
     );

    res.json({ message: "Usuario actualizado correctamente" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error al actualizar el usuario" });
  }
};

//-----------------Eliminar datos --------------------//
export const deleteUser = async (req, res) => {
  try {
    const [result] = await pool.query(
      "DELETE FROM usuarios WHERE id_usuario = ?",
      [req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Usuario no encontrado" });
    }

    return res.sendStatus(204);
  } catch (error) {
    res.status(500).json({ message: "Error al eliminar el usuario" });
  }
};
