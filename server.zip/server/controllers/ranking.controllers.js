import { pool } from "../db.js";

//-----------------Recivir datos --------------------//
export const getRankings = async (req, res) => {
  try {
    const [result] = await pool.query("SELECT * FROM ranking");
    res.json(result);
  } catch (error) {
    res.status(500).json({ message: "Error al obtener el ranking" });
  }
};

//-----------------Recivir nombre de ranking --------------------//
export const nombreRanking = async (req, res) => {
  try {
    const [nameranking] = await pool.query(
      "SELECT nombre, id_ranking  FROM ranking WHERE id_ranking = (SELECT MAX(id_ranking) FROM ranking)"
    );
    if (nameranking.length === 0) {
      return res.status(404).json({ message: "ranking no encontrado" });
    }

    res.json(nameranking[0]);
  } catch (error) {
    res.status(500).json({ message: "Error al obtener el Nombre de Ranking" });
  }
};

//-----------------Recivir un dato --------------------//
export const getRanking = async (req, res) => {
  try {
    const [result] = await pool.query(
      "SELECT r.id_ranking, c.id_cancione, c.titulo, c.artista, c.link, IFNULL(v.total_votos, 0) AS votos_can FROM ( SELECT * FROM ranking WHERE id_ranking = (SELECT MAX(id_ranking) FROM ranking)) AS r JOIN canciones c ON c.id_cancione IN ( r.can1, r.can2, r.can3, r.can4, r.can5, r.can6, r.can7, r.can8, r.can9, r.can10, r.can11, r.can12, r.can13, r.can14, r.can15, r.can16, r.can17, r.can18, r.can19, r.can20 ) LEFT JOIN ( SELECT id_cancione, SUM(votos_can) AS total_votos FROM votos GROUP BY id_cancione ) AS v ON v.id_cancione = c.id_cancione ORDER BY votos_can DESC;"
    );

    if (result.length === 0) {
      return res.status(404).json({ message: "ranking no encontrado" });
    }

    res.json(result);
  } catch (error) {
    res.status(500).json({ message: "Error al obtener el ranking" });
  }
};

//-----------------Crear datos --------------------//
export const postRanking = async (req, res) => {
  try {
    const {
      nombre,
      can1,
      can2,
      can3,
      can4,
      can5,
      can6,
      can7,
      can8,
      can9,
      can10,
      can11,
      can12,
      can13,
      can14,
      can15,
      can16,
      can17,
      can18,
      can19,
      can20,
    } = req.body;
    const [result] = await pool.query(
      "INSERT INTO ranking (nombre, can1,can2,can3,can4,can5,can6,can7,can8,can9,can10,can11,can12,can13,can14,can15,can16,can17,can18,can19,can20) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      [
        nombre,
        can1,
        can2,
        can3,
        can4,
        can5,
        can6,
        can7,
        can8,
        can9,
        can10,
        can11,
        can12,
        can13,
        can14,
        can15,
        can16,
        can17,
        can18,
        can19,
        can20,
      ]
    );
    console.log(result);

    res.json({
      message: "Noticia creada correctamente",
      id: result.insertId,
      nombre,
      can1,
      can2,
      can3,
      can4,
      can5,
      can6,
      can7,
      can8,
      can9,
      can10,
      can11,
      can12,
      can13,
      can14,
      can15,
      can16,
      can17,
      can18,
      can19,
      can20,
    });
  } catch (error) {
    res.status(500).json({ message: "Error al crear el Ranking" });
  }
};

//-----------------Actualizar datos --------------------//
export const putRanking = async (req, res) => {
  try {
    const result = await pool.query(
      "UPDATE ranking SET ? WHERE id_ranking = ?",
      [req.body, req.params.id]
    );
    res.json(result);
  } catch (error) {
    res.status(500).json({ message: "Error al actualizar el ranking" });
  }
};

//-----------------Eliminar datos --------------------//
export const deleteRanking = async (req, res) => {
  try {
    const [result] = await pool.query(
      "DELETE FROM ranking WHERE id_ranking = ?",
      [req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Ranking no encontrada" });
    }

    return res.sendStatus(204);
  } catch (error) {
    res.status(500).json({ message: "Error al eliminar el ranking" });
  }
};
